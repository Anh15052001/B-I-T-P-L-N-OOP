/**
 * 
 */
package controllers;

/**
 * @author Thien Phu
 *
 */
public class bai_xe_controller {
	
}
