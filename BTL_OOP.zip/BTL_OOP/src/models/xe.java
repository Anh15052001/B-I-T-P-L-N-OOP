package models;

//lớp quản lí thông tin các loại xe như tên xe, biển số xe, đăng kí xe
public class xe{
  //các thuộc tính đặc trưng
  private String Tenxe;
  private String Biensoxe;
  private String Dangkixe;
  private String Baohiem;
  //các phương thức get, set
  //phương thức get, set cho tên xe
  public String getTenxe()
  {
      return Tenxe;
  }
  public void setTenxe(String Tenxe)
  {
      this.Tenxe=Tenxe;
  }
  //phương thức get, set cho biển số xe
  public String getBiensoxe()
  {
      return Biensoxe;
  }
  public void setBiensoxe(String Biensoxe)
  {
      this.Biensoxe=Biensoxe;
  }
  //phương thức get, set cho đăng kí xe
  public String getDangkixe()
  {
      return Dangkixe;
  }
  public void setDangkixe(String Dangkixe)
  {
      this.Dangkixe=Dangkixe;
  }
  //phương thức get, set cho bảo hiểm
  public String getBaohiem()
  {
      return Baohiem;
  }
  public void setBaohiem(String Baohiem)
  {
      this.Baohiem=Baohiem;
  }
}