package sample;
import javafx.event.ActionEvent;
public class Controller {
    public void pressButton(ActionEvent event)
    {
        System.out.println("hello world");
    }
}
